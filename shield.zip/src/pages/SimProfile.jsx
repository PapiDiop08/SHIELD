// SimProfile.jsx — FULL LINK — Connecté Supabase via useSimProfile
import { useState } from 'react';
import { useSimProfile } from '../hooks/useSupabase';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
         LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

const RISK_COLOR = (score) => {
  if (score >= 80) return '#ef4444';
  if (score >= 50) return '#f97316';
  if (score >= 30) return '#eab308';
  return '#22c55e';
};

const Badge = ({ label, color = '#6b7280' }) => (
  <span style={{
    background: color + '20', color, border: `1px solid ${color}40`,
    borderRadius: 6, padding: '2px 10px', fontSize: 12, fontWeight: 600
  }}>{label}</span>
);

const ScoreGauge = ({ label, score, color }) => (
  <div style={{ textAlign: 'center', padding: '12px 0' }}>
    <div style={{
      width: 72, height: 72, borderRadius: '50%',
      border: `5px solid ${color}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      margin: '0 auto 8px',
      background: color + '15',
    }}>
      <span style={{ fontSize: 22, fontWeight: 800, color }}>{score ?? '—'}</span>
    </div>
    <div style={{ fontSize: 11, color: '#9ca3af', fontWeight: 600 }}>{label}</div>
  </div>
);

export default function SimProfile() {
  const [inputMsisdn, setInputMsisdn] = useState('');
  const [searchMsisdn, setSearchMsisdn] = useState('');
  const { profile, cdrHistory, simSwaps, relatedAlerts, cellMovements, loading, error, fetchProfile } =
    useSimProfile(searchMsisdn);

  const handleSearch = (e) => {
    e.preventDefault();
    if (inputMsisdn.trim()) {
      setSearchMsisdn(inputMsisdn.trim());
      fetchProfile(inputMsisdn.trim());
    }
  };

  const QUICK = ['221776540001', '221776300001', '221775430001', '221778901001'];

  const radarData = profile ? [
    { subject: 'SIM Box', A: profile.score_simbox || 0 },
    { subject: 'Wangiri',  A: profile.score_wangiri || 0 },
    { subject: 'ATO',      A: profile.score_ato || 0 },
    { subject: 'IRSF',     A: profile.score_irsf || 0 },
  ] : [];

  const globalRisk = profile
    ? Math.max(profile.score_simbox || 0, profile.score_wangiri || 0, profile.score_ato || 0, profile.score_irsf || 0)
    : 0;

  return (
    <div style={{ padding: 24, color: '#e5e7eb', minHeight: '100vh' }}>
      {/* Titre + barre de recherche */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#f9fafb', marginBottom: 4 }}>
          Profil SIM
        </h1>
        <p style={{ color: '#9ca3af', fontSize: 13 }}>
          Analyse complète d'un abonné depuis les CDR et les vues agrégées Supabase
        </p>
      </div>

      <form onSubmit={handleSearch} style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
        <input
          value={inputMsisdn}
          onChange={e => setInputMsisdn(e.target.value)}
          placeholder="Entrer un MSISDN (ex: 221776540001)"
          style={{
            flex: 1, minWidth: 220, padding: '10px 14px',
            background: '#1f2937', border: '1px solid #374151', borderRadius: 8,
            color: '#f9fafb', fontSize: 14,
          }}
        />
        <button type="submit" style={{
          padding: '10px 22px', background: '#6366f1', color: '#fff',
          border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer',
        }}>
          🔍 Analyser
        </button>
      </form>

      {/* Quick picks */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
        <span style={{ fontSize: 12, color: '#6b7280', alignSelf: 'center' }}>Suspects :</span>
        {QUICK.map(m => (
          <button key={m} onClick={() => { setInputMsisdn(m); setSearchMsisdn(m); fetchProfile(m); }}
            style={{
              padding: '4px 12px', background: '#7f1d1d20', color: '#fca5a5',
              border: '1px solid #7f1d1d', borderRadius: 6, fontSize: 12, cursor: 'pointer',
            }}>
            {m}
          </button>
        ))}
      </div>

      {/* States */}
      {!searchMsisdn && (
        <div style={{ textAlign: 'center', padding: 60, color: '#6b7280' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>📱</div>
          <div style={{ fontSize: 16 }}>Entrez un MSISDN pour analyser son profil</div>
        </div>
      )}

      {loading && searchMsisdn && (
        <div style={{ textAlign: 'center', padding: 60, color: '#6b7280' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div>
          <div>Chargement du profil depuis Supabase…</div>
        </div>
      )}

      {error && (
        <div style={{ background: '#7f1d1d20', border: '1px solid #7f1d1d', borderRadius: 8, padding: 16, color: '#fca5a5', marginBottom: 16 }}>
          ⚠️ Erreur : {error}
        </div>
      )}

      {!loading && searchMsisdn && !profile && !error && (
        <div style={{ textAlign: 'center', padding: 60, color: '#6b7280' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>🔍</div>
          <div>Aucun profil trouvé pour <strong style={{ color: '#e5e7eb' }}>{searchMsisdn}</strong></div>
          <div style={{ fontSize: 12, marginTop: 8 }}>Ce MSISDN n'existe pas dans les CDR Supabase</div>
        </div>
      )}

      {profile && !loading && (
        <>
          {/* ── Identité SIM ── */}
          <div style={{
            background: '#111827', border: '1px solid #1f2937', borderRadius: 12,
            padding: 20, marginBottom: 16,
            display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12
          }}>
            <div>
              <div style={{ fontSize: 24, fontWeight: 800, color: '#f9fafb', letterSpacing: 1 }}>
                {profile.msisdn}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                <Badge label={`IMSI: ${profile.imsi || 'N/A'}`} color="#6366f1" />
                <Badge label={`IMEI: ${profile.imei || 'N/A'}`} color="#8b5cf6" />
                <Badge label={profile.operateur || 'Opérateur inconnu'} color="#06b6d4" />
                {profile.cell_id && <Badge label={`Cell: ${profile.cell_id}`} color="#f59e0b" />}
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 4 }}>Risque global</div>
              <div style={{
                fontSize: 48, fontWeight: 900,
                color: RISK_COLOR(globalRisk),
              }}>{globalRisk}</div>
              <div style={{ fontSize: 11, color: RISK_COLOR(globalRisk) }}>
                {globalRisk >= 80 ? '🔴 CRITIQUE' : globalRisk >= 50 ? '🟠 ÉLEVÉ' : globalRisk >= 30 ? '🟡 MOYEN' : '🟢 FAIBLE'}
              </div>
            </div>
          </div>

          {/* ── Scores + Radar ── */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
            <div style={{ background: '#111827', border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#9ca3af', marginBottom: 16 }}>Scores de fraude</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <ScoreGauge label="SIM Box" score={profile.score_simbox} color={RISK_COLOR(profile.score_simbox || 0)} />
                <ScoreGauge label="Wangiri" score={profile.score_wangiri} color={RISK_COLOR(profile.score_wangiri || 0)} />
                <ScoreGauge label="ATO" score={profile.score_ato} color={RISK_COLOR(profile.score_ato || 0)} />
                <ScoreGauge label="IRSF" score={profile.score_irsf} color={RISK_COLOR(profile.score_irsf || 0)} />
              </div>
            </div>

            <div style={{ background: '#111827', border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#9ca3af', marginBottom: 8 }}>Radar de risque</div>
              <ResponsiveContainer width="100%" height={200}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="#374151" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#9ca3af', fontSize: 12 }} />
                  <Radar dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.25} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* ── Activité Voice ── */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginBottom: 16 }}>
            {[
              { label: 'Appels sortants', value: profile.call_count_out ?? '—', icon: '📞' },
              { label: 'Appels entrants', value: profile.call_count_in ?? '—', icon: '📲' },
              { label: 'Durée moy (s)', value: profile.avg_duration ? Math.round(profile.avg_duration) : '—', icon: '⏱' },
              { label: 'SMS sortants', value: profile.sms_count_out ?? '—', icon: '💬' },
              { label: 'Vélocité/heure', value: profile.velocity_hourly ?? '—', icon: '⚡' },
              { label: 'SIM Swaps', value: simSwaps.length, icon: '🔄' },
              { label: 'Alertes liées', value: relatedAlerts.length, icon: '🚨' },
              { label: 'Antennes', value: cellMovements.length, icon: '📡' },
            ].map((s, i) => (
              <div key={i} style={{
                background: '#111827', border: '1px solid #1f2937', borderRadius: 10, padding: 16,
              }}>
                <div style={{ fontSize: 20, marginBottom: 6 }}>{s.icon}</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: '#f9fafb' }}>{s.value}</div>
                <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* ── CDR récent + Alertes ── */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
            {/* CDR */}
            <div style={{ background: '#111827', border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#9ca3af', marginBottom: 12 }}>
                CDR Voice récent (10 derniers)
              </div>
              {cdrHistory.length === 0
                ? <div style={{ color: '#6b7280', fontSize: 13 }}>Aucun CDR trouvé</div>
                : (
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid #1f2937' }}>
                          {['Numéro B', 'Durée', 'Cell', 'Date', 'Flag'].map(h => (
                            <th key={h} style={{ color: '#6b7280', padding: '6px 8px', textAlign: 'left' }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {cdrHistory.map((c, i) => (
                          <tr key={i} style={{ borderBottom: '1px solid #111827' }}>
                            <td style={{ padding: '6px 8px', color: '#e5e7eb' }}>{c.msisdn_b || '—'}</td>
                            <td style={{ padding: '6px 8px', color: '#e5e7eb' }}>{c.duration}s</td>
                            <td style={{ padding: '6px 8px', color: '#9ca3af' }}>{c.cell_id_a}</td>
                            <td style={{ padding: '6px 8px', color: '#9ca3af' }}>
                              {new Date(c.start_time).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}
                            </td>
                            <td style={{ padding: '6px 8px' }}>
                              {c.fraud_flag
                                ? <span style={{ color: '#ef4444', fontWeight: 700 }}>⚠ Fraude</span>
                                : <span style={{ color: '#22c55e' }}>✓</span>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
            </div>

            {/* Alertes liées */}
            <div style={{ background: '#111827', border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#9ca3af', marginBottom: 12 }}>
                Alertes liées à ce MSISDN
              </div>
              {relatedAlerts.length === 0
                ? <div style={{ color: '#6b7280', fontSize: 13 }}>Aucune alerte</div>
                : relatedAlerts.map((a, i) => (
                  <div key={i} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '8px 0', borderBottom: '1px solid #1f2937',
                  }}>
                    <div>
                      <div style={{ fontSize: 13, color: '#e5e7eb', fontWeight: 600 }}>{a.fraud_type}</div>
                      <div style={{ fontSize: 11, color: '#6b7280' }}>
                        {a.triggered_rule_name} — {new Date(a.detected_at).toLocaleDateString('fr-FR')}
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                      <span style={{
                        fontSize: 12, fontWeight: 800,
                        color: RISK_COLOR(a.risk_score || 0)
                      }}>{a.risk_score}</span>
                      <Badge
                        label={a.status}
                        color={a.status === 'blocked' ? '#ef4444' : a.status === 'resolved' ? '#22c55e' : '#f59e0b'}
                      />
                    </div>
                  </div>
                ))
              }
            </div>
          </div>

          {/* ── SIM Swaps + Déplacements Antennes ── */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {/* SIM Swaps */}
            <div style={{ background: '#111827', border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#9ca3af', marginBottom: 12 }}>
                Historique SIM Swap ({simSwaps.length})
              </div>
              {simSwaps.length === 0
                ? <div style={{ color: '#22c55e', fontSize: 13 }}>✓ Aucun SIM Swap détecté</div>
                : simSwaps.map((s, i) => (
                  <div key={i} style={{
                    padding: '8px 0', borderBottom: '1px solid #1f2937',
                    display: 'flex', justifyContent: 'space-between',
                  }}>
                    <div>
                      <div style={{ fontSize: 12, color: '#e5e7eb' }}>
                        {s.old_iccid} → {s.new_iccid}
                      </div>
                      <div style={{ fontSize: 11, color: '#6b7280' }}>
                        {new Date(s.swap_date).toLocaleString('fr-FR')}
                      </div>
                    </div>
                    <Badge label={s.reason || 'Inconnu'} color="#f59e0b" />
                  </div>
                ))}
            </div>

            {/* Antennes fréquentées */}
            <div style={{ background: '#111827', border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#9ca3af', marginBottom: 12 }}>
                Antennes fréquentées ({cellMovements.length})
              </div>
              {cellMovements.length === 0
                ? <div style={{ color: '#6b7280', fontSize: 13 }}>Aucun mouvement</div>
                : cellMovements.slice(0, 6).map((c, i) => (
                  <div key={i} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '6px 0', borderBottom: '1px solid #1f2937',
                  }}>
                    <span style={{ fontSize: 13, color: '#e5e7eb', fontWeight: 600 }}>{c.cellId}</span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{
                        height: 8, width: Math.max(30, (c.count / (cellMovements[0]?.count || 1)) * 100),
                        background: i === 0 ? '#ef4444' : '#6366f1', borderRadius: 4,
                      }} />
                      <span style={{ fontSize: 12, color: '#9ca3af', minWidth: 30 }}>{c.count}x</span>
                    </div>
                  </div>
                ))}
              {cellMovements.length === 1 && (
                <div style={{ marginTop: 8, fontSize: 11, color: '#ef4444' }}>
                  ⚠ SIM toujours sur la même antenne — indicateur SIM Box
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}